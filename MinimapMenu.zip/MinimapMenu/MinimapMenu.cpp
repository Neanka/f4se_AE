﻿#include "MinimapMenu.h"


#include "NiTextures.h"
#include "ScaleformLoader.h"

NiTexture * bgtexture = nullptr;
bool bgtextureMounted = false;


std::map<std::string, NiTexture*> texloaded;

PipboyObject * player;
PipboyPrimitiveThrottledValue<float>* X = nullptr;
PipboyPrimitiveThrottledValue<float>* Rotation = nullptr;
PipboyPrimitiveThrottledValue<float>* Y = nullptr;
PipboyPrimitiveValue<BSFixedString>* TextureName = nullptr;
float _x = 0;
float _y = 0;
float _rotation = 0;
std::string _texturename = "";

void MinimapMenu::SetMapParams()
{
    _MESSAGE("SetMapParams");
    _x = 0;
    _y = 0;
    _rotation = 0;
    mcwidth = texloaded[_texturename]->rendererData->width;
    mcheight = texloaded[_texturename]->rendererData->height;
    _MESSAGE("Texture: width: %i, height: %i", mcwidth, mcheight);
    
    auto worldmapextentsObject = (*g_PipboyDataManager)->mapData.worldMapExtents;
    NWCorner.x = static_cast<PipboyPrimitiveValue<float>*>(worldmapextentsObject->table.Find(&BSFixedString("NWX"))->value)->value;
    NWCorner.y = static_cast<PipboyPrimitiveValue<float>*>(worldmapextentsObject->table.Find(&BSFixedString("NWY"))->value)->value;
    NECorner.x = static_cast<PipboyPrimitiveValue<float>*>(worldmapextentsObject->table.Find(&BSFixedString("NEX"))->value)->value;
    NECorner.y = static_cast<PipboyPrimitiveValue<float>*>(worldmapextentsObject->table.Find(&BSFixedString("NEY"))->value)->value;
    SWCorner.x = static_cast<PipboyPrimitiveValue<float>*>(worldmapextentsObject->table.Find(&BSFixedString("SWX"))->value)->value;
    SWCorner.y = static_cast<PipboyPrimitiveValue<float>*>(worldmapextentsObject->table.Find(&BSFixedString("SWY"))->value)->value;
    _MESSAGE("corners: %f %f %f %f", NECorner.x, NECorner.y, SWCorner.x, SWCorner.y);
    if (_texturename.find("WorldMap_d") != std::string::npos)
    {
        LEFT_GUTTER_PCT = 0.02685546875;
        RIGHT_GUTTER_PCT = 0.0283203125;
        TOP_GUTTER_PCT = 0.02685546875;
        BOTTOM_GUTTER_PCT = 0.0283203125;
    }
    else if (_texturename.find("MapFarHarbor") != std::string::npos)
    {
        LEFT_GUTTER_PCT = 0.00920067;
        RIGHT_GUTTER_PCT = 0.03374173;
        TOP_GUTTER_PCT = 0.02515624;
        BOTTOM_GUTTER_PCT = 0.00958931;
    }
    else if (_texturename.find("NukaWorldMap") != std::string::npos)
    {
        LEFT_GUTTER_PCT = -0.045;
        RIGHT_GUTTER_PCT = -0.095;
        TOP_GUTTER_PCT = 0.0005;
        BOTTOM_GUTTER_PCT = -0.155;
    }
    else
    {
        LEFT_GUTTER_PCT = 0.02685546875;
        RIGHT_GUTTER_PCT = 0.0283203125;
        TOP_GUTTER_PCT = 0.02685546875;
        BOTTOM_GUTTER_PCT = 0.0283203125;
    }
    _MESSAGE("gutters: %f %f %f %f", LEFT_GUTTER_PCT, RIGHT_GUTTER_PCT, TOP_GUTTER_PCT, BOTTOM_GUTTER_PCT);
}

MinimapMenu::MinimapMenu() :GameMenuBase()
{
    flags = kFlag_AllowSaving | kFlag_DontHideCursorWhenTopmost | kFlag_CustomRendering | kFlag_CompanionAppAllowed; // 
    depth = 0x6;
    if (CALL_MEMBER_FN((*g_scaleformManager), LoadMovie)(this, this->movie, "MinimapMenu", "root1.Menu_mc", 1))
    {
        _DMESSAGE("LoadMovie done");
        CreateBaseShaderTarget(this->filterHolder, this->stage);
        this->filterHolder->SetFilterColor(false);
        
        (*g_colorUpdateDispatcher)->eventDispatcher.AddEventSink(this->filterHolder);

        this->shaderFXObjects.Push(this->filterHolder);
        
        auto mapDataObject = (*g_PipboyDataManager)->mapData.mapDataObject;
        auto worldObject = static_cast<PipboyObject*>(mapDataObject->table.Find(&BSFixedString("World"))->value);
        auto playerObject = static_cast<PipboyObject*>(worldObject->table.Find(&BSFixedString("Player"))->value);
        X = static_cast<PipboyPrimitiveThrottledValue<float>*>(playerObject->table.Find(&BSFixedString("X"))->value);
        Rotation = static_cast<PipboyPrimitiveThrottledValue<float>*>(playerObject->table.Find(&BSFixedString("Rotation"))->value);
        Y = static_cast<PipboyPrimitiveThrottledValue<float>*>(playerObject->table.Find(&BSFixedString("Y"))->value);

        if (texloaded.find(_texturename) != texloaded.end())
        {
            _MESSAGE("%s already mounted", _texturename.c_str());
            SetMapParams();
        }
        else
        {
            NiTexture * bgtexture = nullptr;
            LoadTextureByPath(_texturename.c_str(), true, bgtexture, 0, 0, 0);
            if (bgtexture)
            {
                _MESSAGE("%s texture loaded", _texturename.c_str());
                {
                    auto imageLoader = (*g_scaleformManager)->imageLoader;
                    if (imageLoader)
                    {                    
                        bgtexture->name = _texturename.c_str();
                        bgtexture->IncRef();
                        imageLoader->MountImage(&bgtexture);
                        texloaded[_texturename] = bgtexture;
                        SetMapParams();
                    }
                }
                // LoadTextureByPath increases refcount
                bgtexture->DecRef();
            }
        }
        
/*
        {
            
            LoadTextureByPath("Textures\\Interface\\Pip-Boy\\WorldMap_d.dds", true, bgtexture, 0, 0, 0);
            if (bgtexture)
            {
                _MESSAGE("texture loaded");
                if (bgtextureMounted)
                {
                    _MESSAGE("already mounted");
                }
                {
                    auto imageLoader = (*g_scaleformManager)->imageLoader;
                    if (imageLoader)
                    {                    
                        bgtexture->name = "worldmap";
                        bgtexture->IncRef();
                        imageLoader->MountImage(&bgtexture);
                        //texloaded[_texturename] = bgtexture;
                        SetMapParams();
                        bgtextureMounted = true;
                    }
                }
                // LoadTextureByPath increases refcount
                bgtexture->DecRef();
            }
        }*/

        GFxValue texname;
        this->movie->movieRoot->CreateString(&texname, BSFixedString(std::string("img://").append(_texturename).c_str()));
        this->movie->movieRoot->Invoke("root.Menu_mc.LoadBG", nullptr, &texname, 1);
    }
}

void MinimapMenu::Invoke(Args* args)
{
    switch (args->optionID)
    {
    case 0:
        {

        }
        break;
    case 1:
        {

        }
        break;
    default:
        break;
    }
}

void MinimapMenu::AdvanceMovie(float unk0, void* unk1)
{
    //_DMESSAGE("MinimapMenu::AdvanceMovie");
    //_DMESSAGE("%f %f %f", X->value, Y->value, Rotation->value);
    //GFxValue loaded;
    //this->movie->movieRoot->GetVariable(&loaded, "root.Menu_mc.texloaded");
    //_DMESSAGE("texture loaded: %i", loaded.GetBool());
    if (_rotation != Rotation->value)
    {
        _rotation = Rotation->value;
        this->movie->movieRoot->SetVariable("root.Menu_mc.mapinst_mc.map_submc.rotation", &GFxValue(-_rotation));
    }
    //_MESSAGE("%f %f %f %f", _x, X->value, _y, Y->value);
    if (_x != X->value || _y != Y->value)
    {
        _x = X->value;
        _y = Y->value;
        NiPoint2 pos = ConvertWorldToLocalMarkerPosition(_x, _y);
        //_MESSAGE("%f %f", pos.x, pos.y);
        this->movie->movieRoot->SetVariable("root.Menu_mc.mapinst_mc.map_submc.TextureHolder_mc.x", &GFxValue(-pos.x));
        this->movie->movieRoot->SetVariable("root.Menu_mc.mapinst_mc.map_submc.TextureHolder_mc.y", &GFxValue(-pos.y));
    }
    return this->GameMenuBase::AdvanceMovie(unk0, unk1);
};

void MinimapMenu::RegisterFunctions()
{
    this->RegisterNativeFunction("f0", 0);
    this->RegisterNativeFunction("f1", 1);
}

UInt32 MinimapMenu::ProcessMessage(UIMessage* msg)
{
    switch (msg->type)
    {
    case kMessage_Open:
        {
            break;
        }
    case kMessage_Close:
        {
            break;
        }
    default:
        break;
    }
    return this->GameMenuBase::ProcessMessage(msg);
}

IMenu* MinimapMenu::CreateMinimapMenu()
{
    return new MinimapMenu();
}

void MinimapMenu::OpenMenu()
{
    _MESSAGE("Open menu");
    static BSFixedString menuName("MinimapMenu");
    CALL_MEMBER_FN((*g_uiMessageManager), SendUIMessage)(menuName, kMessage_Open);
}

void MinimapMenu::CloseMenu()
{
    _MESSAGE("Close menu");
    static BSFixedString menuName("MinimapMenu");
    CALL_MEMBER_FN((*g_uiMessageManager), SendUIMessage)(menuName, kMessage_Close);
}

void MinimapMenu::RegisterMenu()
{
    static BSFixedString menuName("MinimapMenu");
    if ((*g_ui) != nullptr && !(*g_ui)->IsMenuRegistered(menuName))
    {
        (*g_ui)->Register("MinimapMenu", CreateMinimapMenu);
    }
    _DMESSAGE("RegisterMenu %s", (*g_ui)->IsMenuRegistered(menuName) ? "registered" : "not registered");
}