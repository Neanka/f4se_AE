﻿#pragma once
#include "GameMenus.h"
#include "main.h"

extern std::map<std::string, NiTexture*> texloaded;
extern PipboyObject * player;
extern PipboyPrimitiveThrottledValue<float>* X;
extern PipboyPrimitiveThrottledValue<float>* Rotation;
extern PipboyPrimitiveThrottledValue<float>* Y;
extern PipboyPrimitiveValue<BSFixedString>* TextureName;
extern float _x;
extern float _y;
extern float _rotation;
extern std::string _texturename;

class MinimapMenu : public GameMenuBase
{
public:

    MinimapMenu();
    void Invoke(Args * args) final;
    void AdvanceMovie(float unk0, void* unk1);
    void RegisterFunctions() final;
    UInt32 ProcessMessage(UIMessage * msg) final;
    static IMenu * CreateMinimapMenu();
    static void OpenMenu();
    static void CloseMenu();
    static void RegisterMenu();
    static void SetMapParams();
};
