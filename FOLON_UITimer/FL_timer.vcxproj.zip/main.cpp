#include "main.h"

#include <regex>
#include <shlobj_core.h>
#include "GameMenus.h"
#include "PluginAPI.h"
#include "f4se_common/f4se_version.h"
#include "ScaleformLoader.h"

std::string mName = "FL_timer";
UInt32 mVer = 1;

std::string QuestText;
UInt32 QuestTimer;

PluginHandle g_pluginHandle = kPluginHandle_Invalid;

F4SEMessagingInterface* g_messaging = nullptr;
F4SEPapyrusInterface* g_papyrus = NULL;

class FL_timer_menu : public GameMenuBase
{
public:
	FL_timer_menu() : GameMenuBase()
	{
		flags = kFlag_AllowSaving | kFlag_DontHideCursorWhenTopmost | kFlag_CompanionAppAllowed | kFlag_CustomRendering;// | kFlag_AlwaysOpen;
		depth = 0x6;
		if (CALL_MEMBER_FN((*g_scaleformManager), LoadMovie)(this, this->movie, "FL_timer_menu", "root1.Menu_mc", 2))
		{

			_DMESSAGE("LoadMovie FL_timer_menu done");

			CreateBaseShaderTarget(this->filterHolder, this->stage);

			this->filterHolder->SetFilterColor(false);
			(*g_colorUpdateDispatcher)->eventDispatcher.AddEventSink(this->filterHolder);

			this->shaderFXObjects.Push(this->filterHolder);
		}
	}

	static IMenu* CreateFL_timer_menu()
	{
		return new FL_timer_menu();
	}

	static void OpenMenu()
	{
		static BSFixedString menuName("FL_timer_menu");
		CALL_MEMBER_FN((*g_uiMessageManager), SendUIMessage)(menuName, kMessage_Open);
	}

	static void CloseMenu()
	{
		static BSFixedString menuName("FL_timer_menu");
		CALL_MEMBER_FN((*g_uiMessageManager), SendUIMessage)(menuName, kMessage_Close);
	}

	static void RegisterMenu()
	{
		static BSFixedString menuName("FL_timer_menu");
		if ((*g_ui) != nullptr && !(*g_ui)->IsMenuRegistered(menuName))
		{
			(*g_ui)->Register("FL_timer_menu", CreateFL_timer_menu);
		}
		_DMESSAGE("RegisterMenu %s", (*g_ui)->IsMenuRegistered(menuName) ? "registered" : "not registered");
	}
};

void MessageCallback(F4SEMessagingInterface::Message* msg)
{
	switch (msg->type)
	{
	case F4SEMessagingInterface::kMessage_GameLoaded:
		FL_timer_menu::RegisterMenu();
		break;
	default:
		break;
	}
}

#include "f4se/PapyrusVM.h"
#include "f4se/PapyrusNativeFunctions.h"

bool pap_start(StaticFunctionTag*)
{
	FL_timer_menu::OpenMenu();
	return true;
}

bool pap_stop(StaticFunctionTag*)
{
	FL_timer_menu::CloseMenu();
	return true;
}

bool Update(UInt32 time)
{
	IMenu* menu = (*g_ui)->GetMenu(BSFixedString("FL_timer_menu"));
	if (!menu) return false;
	GFxMovieRoot* movieRoot = menu->movie->movieRoot;
	GFxValue StringValue;
	int mins, secs;
	mins = time/60;
	secs = time%60;
	char str1[256];
	sprintf_s(str1, sizeof(str1), "%s: %i:%02i", QuestText.c_str(), mins, secs);
	movieRoot->CreateString(&StringValue, str1);
	movieRoot->Invoke("root.Menu_mc.text_mc.set_text", nullptr, &StringValue, 1);
	movieRoot->Invoke("root.Menu_mc.bar_mc.set_value", nullptr, &GFxValue(time), 1);
	return true;
}

bool pap_init(StaticFunctionTag*, BSFixedString str, UInt32 time)
{
	QuestText = str;
	QuestTimer = time;
	IMenu* menu = (*g_ui)->GetMenu(BSFixedString("FL_timer_menu"));
	if (!menu) return false;
	GFxMovieRoot* movieRoot = menu->movie->movieRoot;
	movieRoot->Invoke("root.Menu_mc.bar_mc.set_max_value", nullptr, &GFxValue(time), 1);
	Update(time);
	return true;
}

bool pap_update(StaticFunctionTag*, UInt32 time)
{
	Update(time);
	return true;
}

bool RegisterFuncs(VirtualMachine* vm)
{
	vm->RegisterFunction(
		new NativeFunction0 <StaticFunctionTag, bool>("Start", "FL_timer", pap_start, vm));
	vm->RegisterFunction(
		new NativeFunction0 <StaticFunctionTag, bool>("Stop", "FL_timer", pap_stop, vm));
	vm->RegisterFunction(
		new NativeFunction2 <StaticFunctionTag, bool, BSFixedString, UInt32>("InitValues", "FL_timer", pap_init, vm));
	vm->RegisterFunction(
		new NativeFunction1 <StaticFunctionTag, bool, UInt32>("UpdateValues", "FL_timer", pap_update, vm));
	return true;
}

extern "C"
{

	bool F4SEPlugin_Query(const F4SEInterface * f4se, PluginInfo * info)
	{
		gLog.OpenRelative(CSIDL_MYDOCUMENTS, (const char*)("\\My Games\\Fallout4\\F4SE\\"+ mName +".log").c_str());
		_MESSAGE("query");
		// populate info structure
		info->infoVersion =	PluginInfo::kInfoVersion;
		info->name =		mName.c_str();
		info->version =		mVer;

		// store plugin handle so we can identify ourselves later
		g_pluginHandle = f4se->GetPluginHandle();

		// Check game version
		if (f4se->runtimeVersion != CURRENT_RUNTIME_VERSION) {
			char str[512];
			sprintf_s(str, sizeof(str), "Your game version: v%d.%d.%d.%d\nExpected version: v%d.%d.%d.%d\n%s will be disabled.",
				GET_EXE_VERSION_MAJOR(f4se->runtimeVersion),
				GET_EXE_VERSION_MINOR(f4se->runtimeVersion),
				GET_EXE_VERSION_BUILD(f4se->runtimeVersion),
				GET_EXE_VERSION_SUB(f4se->runtimeVersion),
				GET_EXE_VERSION_MAJOR(CURRENT_RUNTIME_VERSION),
				GET_EXE_VERSION_MINOR(CURRENT_RUNTIME_VERSION),
				GET_EXE_VERSION_BUILD(CURRENT_RUNTIME_VERSION),
				GET_EXE_VERSION_SUB(CURRENT_RUNTIME_VERSION),
				mName.c_str()
			);

			MessageBox(NULL, str, mName.c_str(), MB_OK | MB_ICONEXCLAMATION);
			return false;
		}
		g_papyrus = (F4SEPapyrusInterface*)f4se->QueryInterface(kInterface_Papyrus);
		if (!g_papyrus)
		{
			_MESSAGE("couldn't get papyrus interface");
			return false;
		}
		else {
			_MESSAGE("got papyrus interface");
		}

		g_messaging = (F4SEMessagingInterface*)f4se->QueryInterface(kInterface_Messaging);
		if (!g_messaging)
		{
			_FATALERROR("couldn't get messaging interface");
			return false;
		}
		return true;
	}

	bool F4SEPlugin_Load(const F4SEInterface *f4se)
	{
		_MESSAGE("load");
		if (g_messaging != nullptr)
			g_messaging->RegisterListener(g_pluginHandle, "F4SE", MessageCallback);
		if (g_papyrus)
		{
			g_papyrus->Register(RegisterFuncs);
			_MESSAGE("Papyrus Register Succeeded");
		}
		return true;
	}
};
