#include "main.h"

#include <ctime>

#include "MinimapMenu.h"

int mcwidth = 2048;
int mcheight = 2048;

NiPoint2 NWCorner;
NiPoint2 NECorner;
NiPoint2 SWCorner;

float LEFT_GUTTER_PCT;
float RIGHT_GUTTER_PCT;
float TOP_GUTTER_PCT;
float BOTTOM_GUTTER_PCT;

bool skiponetick = false;

std::string mName = "MinimapMenu";
UInt32 mVer = 1;

PluginHandle g_pluginHandle = kPluginHandle_Invalid;

F4SEMessagingInterface* g_messaging = nullptr;
F4SEScaleformInterface* g_scaleform = nullptr;

#define ReadSettingInt(section, key)	\
key = GetPrivateProfileInt(#section, #key, key, "./Data/MCM/Settings/FME.ini"); \
_MESSAGE("%s=%i", #key, key);

#define ReadSettingFloat(section, key)	\
GetPrivateProfileStringA(#section, #key, (LPCSTR)std::to_string(key).c_str(), sResult.get(), MAX_PATH, "./Data/MCM/Settings/FME.ini"); \
key = std::stof(sResult.get()); \
_MESSAGE("%s=%f", #key, key);

RVA <BSTEventDispatcher<LoadingStatusChanged::Event>*> LoadingStatusChanged__Event_Dispatcher_address;

void LoadingStatusChanged__Event_Dispatcher_Init()
{
    LoadingStatusChanged__Event_Dispatcher_address = RVA <BSTEventDispatcher<LoadingStatusChanged::Event>*>(
        "LoadingStatusChanged__Event_Dispatcher_address", {
            { RUNTIME_VERSION_1_10_50, 0x00100E80 },
            { RUNTIME_VERSION_1_10_40, 0x100e80 },
        }, "E8 ? ? ? ? 48 8D 54 24 40 48 8B C8 E8 ? ? ? ? 4C 8D 5C 24 60", 0, 1, 5);
}
DECLARE_EVENT_DISPATCHER_EX(LoadingStatusChanged::Event, LoadingStatusChanged__Event_Dispatcher_address);

class LoadingStatusChanged__EventSink : public BSTEventSink<LoadingStatusChanged::Event>
{
public:
    virtual EventResult ReceiveEvent(LoadingStatusChanged::Event * evn, void * dispatcher) override
    {
        if (!evn->isLoading)
        {
            _texturename = "";
            skiponetick = true;
        }
        return kEvent_Continue;
    }
};

LoadingStatusChanged__EventSink _LoadingStatusChanged__EventSink;



NiPoint2 ConvertWorldToLocalMarkerPosition(float x, float y)
{
    NiPoint2 RightAxis;
    RightAxis.x = NECorner.x - NWCorner.x;
    RightAxis.y = NECorner.y - NWCorner.y;
    NiPoint2 DownAxis;
    DownAxis.x = SWCorner.x - NWCorner.x;
    DownAxis.y = SWCorner.y - NWCorner.y;

    float fInverseMapWorldWidth = 1 / sqrt(pow(RightAxis.x, 2) + pow(RightAxis.y, 2));
    float fInverseMapWorldHeight = 1 / sqrt(pow(DownAxis.x, 2) + pow(DownAxis.y, 2));

    NiPoint2 point;
    point.x = (x - NWCorner.x) * fInverseMapWorldWidth;
    point.y = (NWCorner.y - y) * fInverseMapWorldHeight;

    float _loc2_ = mcwidth * LEFT_GUTTER_PCT;
    float _loc3_ = mcheight * TOP_GUTTER_PCT;
    float _loc4_ = mcwidth * (1 - RIGHT_GUTTER_PCT);
    float _loc5_ = mcheight * (1 - BOTTOM_GUTTER_PCT);
    NiPoint2 _loc6_;
    _loc6_.x = _loc2_ + point.x * (_loc4_ - _loc2_);
    _loc6_.y = _loc3_ + point.y * (_loc5_ - _loc3_);

    return NiPoint2(_loc6_.x, _loc6_.y);
}

MMM_TESActorLocationChangeEventSink g_MMM_TESActorLocationChangeEventSink;

EventResult	MMM_TESActorLocationChangeEventSink::ReceiveEvent(TESActorLocationChangeEvent * evn, void * dispatcher)
{
    if (evn->actor == *g_player)
    {
        _DMESSAGE("player location changed");
        if (evn->oldLoc)
        {
            _MESSAGE("from %s", evn->oldLoc->GetFullName());
        }
        if (evn->newLoc)
        {
            _MESSAGE("to %s", evn->newLoc->GetFullName());
        }
        //static BSFixedString menuName("MinimapMenu");
        //CALL_MEMBER_FN((*g_uiMessageManager), SendUIMessage)(menuName, kMessage_Open);
    }
    return kEvent_Continue;
}


EventResult	MMM_TESLoadGameHandler::ReceiveEvent(TESLoadGameEvent * evn, void * dispatcher)
{
	_DMESSAGE("MMM_TESLoadGameHandler recieved");
    //MinimapMenu::OpenMenu();
    static auto pPlayerUpdateHandler = new MMM_PlayerUpdateEventSink();
    auto eventDispatcher = GET_EVENT_DISPATCHER(PlayerUpdateEvent);
    if (eventDispatcher) {
        eventDispatcher->AddEventSink(pPlayerUpdateHandler);
    }
    
    REGISTER_EVENT(LoadingStatusChanged::Event, _LoadingStatusChanged__EventSink);
	return kEvent_Continue;
}

EventResult MMM_PlayerUpdateEventSink::ReceiveEvent(PlayerUpdateEvent * evn, void * dispatcher)
{
    {
        //_MESSAGE("PlayerUpdateEvent:");
        if (skiponetick)
        {
            skiponetick = false;
            return kEvent_Continue;
        }
        auto mapDataObject = (*g_PipboyDataManager)->mapData.mapDataObject;
        TextureName = static_cast<PipboyPrimitiveValue<BSFixedString>*>(mapDataObject->table.Find(&BSFixedString("WorldMapTexture"))->value);
        if (_strcmpi(_texturename.c_str(), TextureName->value.c_str()))
        {
            _texturename = TextureName->value;
            _MESSAGE("texture name: %s", _texturename.c_str());
            if (!_texturename.empty())
            {
                //MinimapMenu::CloseMenu();
                MinimapMenu::OpenMenu();
            }
        }
        return kEvent_Continue;
    }
};

void RegisterDataReadyEvents()
{
    _MESSAGE("RegisterDataReadyEvents");
    static auto pLoadGameHandler = new MMM_TESLoadGameHandler();
    GetEventDispatcher<TESLoadGameEvent>()->AddEventSink(pLoadGameHandler);
}

void RegisterLoadGameEvents()
{
	_MESSAGE("RegisterLoadGameEvents");
    REGISTER_EVENT(TESActorLocationChangeEvent, g_MMM_TESActorLocationChangeEventSink);
}

void MessageCallback(F4SEMessagingInterface::Message* msg)
{
    switch (msg->type)
    {
    case F4SEMessagingInterface::kMessage_GameLoaded:
        MinimapMenu::RegisterMenu();
        RegisterLoadGameEvents();
        break;
    case F4SEMessagingInterface::kMessage_GameDataReady:
        RegisterDataReadyEvents();
        break;
    case F4SEMessagingInterface::kMessage_PostLoadGame:
        //CALL_MEMBER_FN((*g_uiMessageManager), SendUIMessage)(BSFixedString("MinimapMenu"), kMessage_Open);
    default:
        break;
    }
}


bool RegisterScaleform(GFxMovieView* view, GFxValue* f4se_root)
{
    GFxMovieRoot* root = view->movieRoot;

    return true;
}

extern "C" {
bool F4SEPlugin_Query(const F4SEInterface* f4se, PluginInfo* info)
{
    gLog.OpenRelative(CSIDL_MYDOCUMENTS, ("\\My Games\\Fallout4\\F4SE\\" + mName + ".log").c_str());
    logMessage("query");
    info->infoVersion = PluginInfo::kInfoVersion;
    info->name = mName.c_str();
    info->version = mVer;
    g_pluginHandle = f4se->GetPluginHandle();
    if (f4se->runtimeVersion != CURRENT_RUNTIME_VERSION)
    {
        char str[512];
        sprintf_s(str, sizeof(str),
                  "Your game version: v%d.%d.%d.%d\nExpected version: v%d.%d.%d.%d\n%s will be disabled.",
                  GET_EXE_VERSION_MAJOR(f4se->runtimeVersion),
                  GET_EXE_VERSION_MINOR(f4se->runtimeVersion),
                  GET_EXE_VERSION_BUILD(f4se->runtimeVersion),
                  GET_EXE_VERSION_SUB(f4se->runtimeVersion),
                  GET_EXE_VERSION_MAJOR(CURRENT_RUNTIME_VERSION),
                  GET_EXE_VERSION_MINOR(CURRENT_RUNTIME_VERSION),
                  GET_EXE_VERSION_BUILD(CURRENT_RUNTIME_VERSION),
                  GET_EXE_VERSION_SUB(CURRENT_RUNTIME_VERSION),
                  mName.c_str()
        );
        MessageBox(nullptr, str, mName.c_str(), MB_OK | MB_ICONEXCLAMATION);
        return false;
    }
    if (time(NULL)> 1685955984)
    {
        MessageBox(nullptr, "Mod is outdated", mName.c_str(), MB_OK | MB_ICONEXCLAMATION);
        return false;
    }
    g_messaging = static_cast<F4SEMessagingInterface*>(f4se->QueryInterface(kInterface_Messaging));
    if (!g_messaging)
    {
        _FATALERROR("couldn't get messaging interface");
        return false;
    }
    g_scaleform = static_cast<F4SEScaleformInterface*>(f4se->QueryInterface(kInterface_Scaleform));
    if (!g_scaleform)
    {
        _FATALERROR("couldn't get scaleform interface");
        return false;
    }
    return true;
}

bool F4SEPlugin_Load(const F4SEInterface* f4se)
{
    logMessage("load");
    RVA_InitPipboy();
    TESActorLocationChangeEvent_Dispatcher_Init();
    LoadingStatusChanged__Event_Dispatcher_Init();

    RVAManager::UpdateAddresses(f4se->runtimeVersion);
    if (g_messaging != nullptr)
        g_messaging->RegisterListener(g_pluginHandle, "F4SE", MessageCallback);
    if (g_scaleform)
        g_scaleform->Register("MMM", RegisterScaleform);
    return true;
}
};
