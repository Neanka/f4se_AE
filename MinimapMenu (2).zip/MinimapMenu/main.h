#pragma once
#include "Shared.h"

extern int mcwidth;
extern int mcheight;
extern NiPoint2 NWCorner;
extern NiPoint2 NECorner;
extern NiPoint2 SWCorner;

extern float LEFT_GUTTER_PCT;
extern float RIGHT_GUTTER_PCT;
extern float TOP_GUTTER_PCT;
extern float BOTTOM_GUTTER_PCT;

class MMM_TESLoadGameHandler : public BSTEventSink<TESLoadGameEvent>
{
public:
    virtual ~MMM_TESLoadGameHandler() { };
    virtual	EventResult	ReceiveEvent(TESLoadGameEvent * evn, void * dispatcher) override;
};

class MMM_TESActorLocationChangeEventSink : public BSTEventSink<TESActorLocationChangeEvent>
{
public:
    virtual	EventResult	ReceiveEvent(TESActorLocationChangeEvent * evn, void * dispatcher) override;
};
extern MMM_TESActorLocationChangeEventSink g_MMM_TESActorLocationChangeEventSink;

class MMM_PlayerUpdateEventSink : public BSTEventSink<PlayerUpdateEvent>
{
public:
    virtual EventResult ReceiveEvent(PlayerUpdateEvent * evn, void * dispatcher) override;
};

NiPoint2 ConvertWorldToLocalMarkerPosition(float x, float y);